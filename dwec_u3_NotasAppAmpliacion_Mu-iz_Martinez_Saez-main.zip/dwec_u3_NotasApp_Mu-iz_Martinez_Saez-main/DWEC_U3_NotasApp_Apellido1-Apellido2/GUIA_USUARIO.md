# Guía de usuario (esquemática)

- Propósito: gestionar notas con filtros Hoy/Semana/Todas.
- Requisitos: navegador moderno; permitir ventanas emergentes para el Panel.
- Tareas: añadir nota; aplicar filtros; abrir Panel; completar/borrar.
- Preferencias (si las incorporas): tema/tamaño.
- Persistencia: indicar mecanismo elegido y sus implicaciones.
- Problemas comunes: pop-ups bloqueados; almacenamiento deshabilitado; idioma del navegador.
